=====================================
Frequently Asked Questions
=====================================

Why the name 'Opera Cake'?
~~~~~~~~~~~~~~~~~~~~~~~~~~

Internally at Great Scott Gadgets, HackRF related boards are code named with a candy or confection name. The Opera Cake code name was fun enough that we didn't change from it when we released the project.

When was Opera Cake first for sale?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Great Scott Gadgets first released Opera Cake for sale in 2022. The open source project for Opera Cake has been available since 2016 from Great Scott Gadgets. 